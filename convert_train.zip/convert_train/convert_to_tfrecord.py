#%matplotlib inline

# Important: We are using PIL to read .png files later.
# This was done on purpose to read indexed png files
# in a special way -- only indexes and not map the indexes
# to actual rgb values. This is specific to PASCAL VOC
# dataset data. If you don't want thit type of behaviour
# consider using skimage.io.imread()
from PIL import Image
import numpy as np
import skimage.io as io
import tensorflow as tf
import glob
import os, os.path

labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 
            'T', 'U', 'V', 'W', 'X', 'Y']

class ImageCoder(object):
  """Helper class that provides TensorFlow image coding utilities."""

  def __init__(self):
    # Create a single Session to run all image coding calls.
    self._sess = tf.Session()

    # Initializes function that converts PNG to JPEG data.
    self._png_data = tf.placeholder(dtype=tf.string)
    image = tf.image.decode_png(self._png_data, channels=3)
    self._png_to_jpeg = tf.image.encode_jpeg(image, format='rgb', quality=100)

    # Initializes function that decodes RGB JPEG data.
    self._decode_jpeg_data = tf.placeholder(dtype=tf.string)
    self._decode_jpeg = tf.image.decode_jpeg(self._decode_jpeg_data, channels=3)

  def png_to_jpeg(self, image_data):
    return self._sess.run(self._png_to_jpeg,
                          feed_dict={self._png_data: image_data})

  def decode_jpeg(self, image_data):
    image = self._sess.run(self._decode_jpeg,
                           feed_dict={self._decode_jpeg_data: image_data})
    assert len(image.shape) == 3
    assert image.shape[2] == 3
    return image

def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))

# Let's collect the real images to later on compare
# to the reconstructed ones
original_images = []
j = 0
coder = ImageCoder()


for i in labels:
    print(j)
    cole_dir = "/home/mrafi/Dataset/"+ i +"/*.jpeg"
    tf_file = i+'_train.tfrecord'
    writer = tf.python_io.TFRecordWriter(tf_file)

    for img_path in glob.glob(cole_dir):

        #with open(img_path) as im:
        with tf.gfile.FastGFile(img_path, 'rb') as f:

            #img = np.array(Image.open(img_path))
            #img = np.array(im.read())
            img = f.read()

            image = coder.decode_jpeg(img)
        
            # The reason to store image sizes was demonstrated
            # in the previous example -- we have to know sizes
            # of images to later read raw serialized string,
            # convert to 1d array and convert to respective
            # shape that image used to have.
            height = image.shape[0]
            width = image.shape[1]
        
            # Put in the original images into array
            # Just for future check for correctness
        

            #img_raw = img.tostring()
        
            example = tf.train.Example(features=tf.train.Features(feature={
                'image/height': _int64_feature(height),
                'image/width': _int64_feature(width),
                'image/text' : _bytes_feature(tf.compat.as_bytes(i)),
                'image/class/label': _int64_feature(j),
                'image/format': _bytes_feature(tf.compat.as_bytes('jpeg')),
                'image/encoded': _bytes_feature(img)}))
        
            writer.write(example.SerializeToString())
    
    j += 1
    writer.close()