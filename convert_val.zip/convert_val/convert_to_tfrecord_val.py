#%matplotlib inline

# Important: We are using PIL to read .png files later.
# This was done on purpose to read indexed png files
# in a special way -- only indexes and not map the indexes
# to actual rgb values. This is specific to PASCAL VOC
# dataset data. If you don't want thit type of behaviour
# consider using skimage.io.imread()
from PIL import Image
import numpy as np
import skimage.io as io
import tensorflow as tf
import glob
import os, os.path

labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 
            'T', 'U', 'V', 'W', 'X', 'Y']



def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))

# Let's collect the real images to later on compare
# to the reconstructed ones
original_images = []
j = 0

for i in labels:
    print(j)
    cole_dir = "/home/mrafi/Val/"+ i +"/*.jpeg"
    tf_file = i+'_val.tfrecord'
    writer = tf.python_io.TFRecordWriter(tf_file)

    for img_path in glob.glob(cole_dir):

        img = np.array(Image.open(img_path))
    
        # The reason to store image sizes was demonstrated
        # in the previous example -- we have to know sizes
        # of images to later read raw serialized string,
        # convert to 1d array and convert to respective
        # shape that image used to have.
        height = img.shape[0]
        width = img.shape[1]
        
        # Put in the original images into array
        # Just for future check for correctness
        

        img_raw = img.tostring()
        
        example = tf.train.Example(features=tf.train.Features(feature={
            'image/height': _int64_feature(height),
            'image/width': _int64_feature(width),
            'image/text' : _bytes_feature(tf.compat.as_bytes(i)),
            'image/class/label': _int64_feature(j),
            'image/format': _bytes_feature(tf.compat.as_bytes('jpeg')),
            'image/encoded': _bytes_feature(img_raw)}))
        
        writer.write(example.SerializeToString())

    j += 1
    writer.close()